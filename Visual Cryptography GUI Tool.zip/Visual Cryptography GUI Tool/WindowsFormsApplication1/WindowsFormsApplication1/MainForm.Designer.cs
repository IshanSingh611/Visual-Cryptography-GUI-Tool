﻿namespace WindowsFormsApplication1
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.vCSharesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.twoSharesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.threeSharesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fourSharesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fiveSharesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vCImageSharesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uploadImagesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.decodeTwoSharesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.decodeMultiSharesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.decodeImageSharesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.vCSharesToolStripMenuItem,
            this.vCImageSharesToolStripMenuItem,
            this.uploadImagesToolStripMenuItem,
            this.decodeImageSharesToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1370, 29);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // vCSharesToolStripMenuItem
            // 
            this.vCSharesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.twoSharesToolStripMenuItem,
            this.threeSharesToolStripMenuItem,
            this.fourSharesToolStripMenuItem,
            this.fiveSharesToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.vCSharesToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.vCSharesToolStripMenuItem.ForeColor = System.Drawing.Color.Green;
            this.vCSharesToolStripMenuItem.Name = "vCSharesToolStripMenuItem";
            this.vCSharesToolStripMenuItem.Size = new System.Drawing.Size(93, 25);
            this.vCSharesToolStripMenuItem.Text = "VC Shares";
            // 
            // twoSharesToolStripMenuItem
            // 
            this.twoSharesToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.twoSharesToolStripMenuItem.Name = "twoSharesToolStripMenuItem";
            this.twoSharesToolStripMenuItem.Size = new System.Drawing.Size(179, 26);
            this.twoSharesToolStripMenuItem.Text = "Two Shares..";
            this.twoSharesToolStripMenuItem.Click += new System.EventHandler(this.twoSharesToolStripMenuItem_Click);
            // 
            // threeSharesToolStripMenuItem
            // 
            this.threeSharesToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.threeSharesToolStripMenuItem.Name = "threeSharesToolStripMenuItem";
            this.threeSharesToolStripMenuItem.Size = new System.Drawing.Size(179, 26);
            this.threeSharesToolStripMenuItem.Text = "Three Shares...";
            this.threeSharesToolStripMenuItem.Click += new System.EventHandler(this.threeSharesToolStripMenuItem_Click);
            // 
            // fourSharesToolStripMenuItem
            // 
            this.fourSharesToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.fourSharesToolStripMenuItem.Name = "fourSharesToolStripMenuItem";
            this.fourSharesToolStripMenuItem.Size = new System.Drawing.Size(179, 26);
            this.fourSharesToolStripMenuItem.Text = "Four Shares...";
            this.fourSharesToolStripMenuItem.Click += new System.EventHandler(this.fourSharesToolStripMenuItem_Click);
            // 
            // fiveSharesToolStripMenuItem
            // 
            this.fiveSharesToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.fiveSharesToolStripMenuItem.Name = "fiveSharesToolStripMenuItem";
            this.fiveSharesToolStripMenuItem.Size = new System.Drawing.Size(179, 26);
            this.fiveSharesToolStripMenuItem.Text = "Five Shares...";
            this.fiveSharesToolStripMenuItem.Click += new System.EventHandler(this.fiveSharesToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(179, 26);
            this.exitToolStripMenuItem.Text = "Exit..";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // vCImageSharesToolStripMenuItem
            // 
            this.vCImageSharesToolStripMenuItem.ForeColor = System.Drawing.Color.Green;
            this.vCImageSharesToolStripMenuItem.Name = "vCImageSharesToolStripMenuItem";
            this.vCImageSharesToolStripMenuItem.Size = new System.Drawing.Size(140, 25);
            this.vCImageSharesToolStripMenuItem.Text = "VC Image Shares";
            this.vCImageSharesToolStripMenuItem.Click += new System.EventHandler(this.vCImageSharesToolStripMenuItem_Click);
            // 
            // uploadImagesToolStripMenuItem
            // 
            this.uploadImagesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.decodeTwoSharesToolStripMenuItem,
            this.decodeMultiSharesToolStripMenuItem});
            this.uploadImagesToolStripMenuItem.ForeColor = System.Drawing.Color.Green;
            this.uploadImagesToolStripMenuItem.Name = "uploadImagesToolStripMenuItem";
            this.uploadImagesToolStripMenuItem.Size = new System.Drawing.Size(149, 25);
            this.uploadImagesToolStripMenuItem.Text = "Decode VC Shares";
            this.uploadImagesToolStripMenuItem.Click += new System.EventHandler(this.uploadImagesToolStripMenuItem_Click);
            // 
            // decodeTwoSharesToolStripMenuItem
            // 
            this.decodeTwoSharesToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.decodeTwoSharesToolStripMenuItem.Name = "decodeTwoSharesToolStripMenuItem";
            this.decodeTwoSharesToolStripMenuItem.Size = new System.Drawing.Size(223, 26);
            this.decodeTwoSharesToolStripMenuItem.Text = "Decode Two Shares";
            this.decodeTwoSharesToolStripMenuItem.Click += new System.EventHandler(this.decodeTwoSharesToolStripMenuItem_Click);
            // 
            // decodeMultiSharesToolStripMenuItem
            // 
            this.decodeMultiSharesToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.decodeMultiSharesToolStripMenuItem.Name = "decodeMultiSharesToolStripMenuItem";
            this.decodeMultiSharesToolStripMenuItem.Size = new System.Drawing.Size(223, 26);
            this.decodeMultiSharesToolStripMenuItem.Text = "Decode Multi Shares";
            this.decodeMultiSharesToolStripMenuItem.Click += new System.EventHandler(this.decodeMultiSharesToolStripMenuItem_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(275, 140);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(836, 368);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripButton2,
            this.toolStripButton3,
            this.toolStripButton4,
            this.toolStripButton5});
            this.toolStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Flow;
            this.toolStrip1.Location = new System.Drawing.Point(0, 29);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.toolStrip1.Size = new System.Drawing.Size(1370, 39);
            this.toolStrip1.TabIndex = 2;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton1.Text = "toolStripButton1";
            this.toolStripButton1.ToolTipText = "Open 2 Shares Form";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton2.Text = "toolStripButton2";
            this.toolStripButton2.ToolTipText = "Open 3 Shares Form";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton3.Text = "toolStripButton3";
            this.toolStripButton3.ToolTipText = "Open 4 Shares Form";
            this.toolStripButton3.Click += new System.EventHandler(this.toolStripButton3_Click);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton4.Text = "toolStripButton4";
            this.toolStripButton4.ToolTipText = "Open 5 Shares Form";
            this.toolStripButton4.Click += new System.EventHandler(this.toolStripButton4_Click);
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton5.Text = "toolStripButton5";
            this.toolStripButton5.ToolTipText = "Image Shares";
            this.toolStripButton5.Click += new System.EventHandler(this.toolStripButton5_Click);
            // 
            // decodeImageSharesToolStripMenuItem
            // 
            this.decodeImageSharesToolStripMenuItem.ForeColor = System.Drawing.Color.Green;
            this.decodeImageSharesToolStripMenuItem.Name = "decodeImageSharesToolStripMenuItem";
            this.decodeImageSharesToolStripMenuItem.Size = new System.Drawing.Size(172, 25);
            this.decodeImageSharesToolStripMenuItem.Text = "Decode Image Shares";
            this.decodeImageSharesToolStripMenuItem.Click += new System.EventHandler(this.decodeImageSharesToolStripMenuItem_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1370, 750);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.Text = "MainForm";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem vCSharesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem twoSharesToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolStripMenuItem threeSharesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fourSharesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fiveSharesToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vCImageSharesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uploadImagesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem decodeTwoSharesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem decodeMultiSharesToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripMenuItem decodeImageSharesToolStripMenuItem;
    }
}