﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class DecodetwoShares : Form
    {
        public DecodetwoShares()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog opd = new OpenFileDialog();
            if (opd.ShowDialog() == DialogResult.OK) {
                pictureBox1.ImageLocation = opd.FileName;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog opd = new OpenFileDialog();
            if (opd.ShowDialog() == DialogResult.OK)
            {
                pictureBox2.ImageLocation = opd.FileName;
            }
        }
        int a = 0;
        private void button3_Click(object sender, EventArgs e)
        {
            pictureBox2.Location = pictureBox1.Location;
            timer1.Start();
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (a % 2 == 0)
            {
                pictureBox1.Visible = false;
                pictureBox2.Visible = true;
            }
            else
            {
                pictureBox1.Visible = true;
                pictureBox2.Visible = false;
            }
            a++;
        }

        private void DecodetwoShares_FormClosing(object sender, FormClosingEventArgs e)
        {
            timer1.Stop();
            this.Dispose();
        }
    }
}
