﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
using System.IO;
using System.Drawing.Imaging;
namespace WindowsFormsApplication1
{
    public partial class ThreeShares : Form
    {
        private Size IMAGE_SIZE = new Size(437, 106);
        private const int GENERATE_IMAGE_COUNT = 3;

        private Bitmap[] m_EncryptedImages;
        public ThreeShares()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                if (m_EncryptedImages != null)
                {
                    for (int i = m_EncryptedImages.Length - 1; i > 0; i--)
                    {
                        m_EncryptedImages[i].Dispose();
                    }
                    Array.Clear(m_EncryptedImages, 0, m_EncryptedImages.Length);
                }

                m_EncryptedImages = GenerateImage(textBox1.Text);

                panelCanvas.Invalidate();
            }
        }
        private Bitmap[] GenerateImage(string inputText)
        {
            Bitmap finalImage = new Bitmap(IMAGE_SIZE.Width, IMAGE_SIZE.Height);
            Bitmap tempImage = new Bitmap(IMAGE_SIZE.Width / 2, IMAGE_SIZE.Height);
            Bitmap[] image = new Bitmap[GENERATE_IMAGE_COUNT];

            Random r = new Random();
            SolidBrush brush = new SolidBrush(Color.Black);
            Point mid = new Point(IMAGE_SIZE.Width / 2, IMAGE_SIZE.Height / 2);

            Graphics g = Graphics.FromImage(finalImage);
            Graphics gtemp = Graphics.FromImage(tempImage);

            StringFormat sf = new StringFormat();
            sf.Alignment = StringAlignment.Center;
            sf.LineAlignment = StringAlignment.Center;
            Font font = new Font("Times New Roman", 48);
            Color fontColor;

            g.DrawString(inputText, font, brush, mid, sf);
            gtemp.DrawImage(finalImage, 0, 0, tempImage.Width, tempImage.Height);


            for (int i = 0; i < image.Length; i++)
            {
                image[i] = new Bitmap(IMAGE_SIZE.Width, IMAGE_SIZE.Height);
            }


            int index = -1;
            int width = tempImage.Width;
            int height = tempImage.Height;
            for (int x = 0; x < width; x += 1)
            {
                for (int y = 0; y < height; y += 1)
                {
                    fontColor = tempImage.GetPixel(x, y);
                    index = r.Next(image.Length);
                    if (fontColor.Name == Color.Empty.Name)
                    {
                        for (int i = 0; i < image.Length; i++)
                        {
                            if (index == 0)
                            {
                                image[i].SetPixel(x * 2, y, Color.Black);
                                image[i].SetPixel(x * 2 + 1, y, Color.Empty);
                            }
                            else
                            {
                                image[i].SetPixel(x * 2, y, Color.Empty);
                                image[i].SetPixel(x * 2 + 1, y, Color.Black);
                            }
                        }
                    }
                    else
                    {
                        for (int i = 0; i < image.Length; i++)
                        {
                            if ((index + i) % image.Length == 0)
                            {
                                image[i].SetPixel(x * 2, y, Color.Black);
                                image[i].SetPixel(x * 2 + 1, y, Color.Empty);
                            }
                            else
                            {
                                image[i].SetPixel(x * 2, y, Color.Empty);
                                image[i].SetPixel(x * 2 + 1, y, Color.Black);
                            }
                        }
                    }
                }
            }

            brush.Dispose();
            tempImage.Dispose();
            finalImage.Dispose();

            return image;
        }

        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            //if (m_EncryptedImages == null)
            //{
            //    MessageBox.Show("Please generate image first", this.Text);
            //    return;
            //}

            //if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            //{
            //    string fileName = Path.GetFileNameWithoutExtension(saveFileDialog1.FileName);
            //    string filePath = saveFileDialog1.FileName;
            //    string savePath = fileName;
            //    for (int i = 0; i < m_EncryptedImages.Length; i++)
            //    {
            //        savePath = filePath.Replace(fileName, fileName + i);
            //        m_EncryptedImages[i].Save(savePath, ImageFormat.Png);
            //    }
            //}
        }

        private void panelCanvas_Paint(object sender, PaintEventArgs e)
        {
            if (m_EncryptedImages != null)
            {
                Graphics g = e.Graphics;
                Rectangle rect = new Rectangle(0, 0, 0, 0);
                for (int i = 0; i < m_EncryptedImages.Length; i++)
                {
                    rect.Size = m_EncryptedImages[i].Size;
                    g.DrawImage(m_EncryptedImages[i], rect);
                    rect.Y += m_EncryptedImages[i].Height + 5;
                }

                g.DrawLine(new Pen(new SolidBrush(Color.Aqua), 2), rect.Location, new Point(rect.Width, rect.Y));
                rect.Y += 5;

                for (int i = 0; i < m_EncryptedImages.Length; i++)
                {
                    rect.Size = m_EncryptedImages[i].Size;
                    g.DrawImage(m_EncryptedImages[i], rect);
                }
            }
        }

        private void saveImageAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (m_EncryptedImages == null)
            {
                MessageBox.Show("Please generate image first", this.Text);
                return;
            }

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string fileName = Path.GetFileNameWithoutExtension(saveFileDialog1.FileName);
                string filePath = saveFileDialog1.FileName;
                string savePath = fileName;
                for (int i = 0; i < m_EncryptedImages.Length; i++)
                {
                    savePath = filePath.Replace(fileName, fileName + i);
                    m_EncryptedImages[i].Save(savePath, ImageFormat.Png);
                }
            }
        }

    }
}
