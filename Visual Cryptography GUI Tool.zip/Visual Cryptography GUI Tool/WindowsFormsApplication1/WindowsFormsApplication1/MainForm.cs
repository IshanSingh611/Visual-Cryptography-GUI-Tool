﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Windows.Forms;
namespace WindowsFormsApplication1
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            pictureBox1.ImageLocation = "crop_image.jpg";
            toolStripButton1.Image = Image.FromFile("misc_numbers_2.png");
            toolStripButton2.Image = Image.FromFile("misc_numbers_3.png");
            toolStripButton3.Image = Image.FromFile("misc_numbers_4.png");
            toolStripButton4.Image = Image.FromFile("misc_numbers_5.png");
            toolStripButton5.Image = Image.FromFile("image 1.png");
        }

        private void twoSharesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            //this.Hide();
            f.ShowDialog();
        }

        private void threeSharesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ThreeShares ts = new ThreeShares();
            ts.ShowDialog();
        }

        private void fourSharesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FourShares f = new FourShares();
            f.ShowDialog();
        }

        private void fiveSharesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FiveShares f = new FiveShares();
            f.ShowDialog();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            //this.Hide();
            f.ShowDialog();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            ThreeShares ts = new ThreeShares();
            ts.ShowDialog();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {

            FourShares f = new FourShares();
            f.ShowDialog();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            FiveShares f = new FiveShares();
            f.ShowDialog();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void uploadImagesToolStripMenuItem_Click(object sender, EventArgs e)
        {
        
        }

        private void decodeTwoSharesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DecodetwoShares d = new DecodetwoShares();
            d.ShowDialog();
        }

        private void decodeMultiSharesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DecodeThreeShares d = new DecodeThreeShares();
            d.ShowDialog();
        }

        private void vCImageSharesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ImageCryptography ic = new ImageCryptography();
            ic.ShowDialog();
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            ImageCryptography ic = new ImageCryptography();
            ic.ShowDialog();
        }

        private void decodeImageSharesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DecodeImages di = new DecodeImages();
            di.ShowDialog();
        }
    }
}
